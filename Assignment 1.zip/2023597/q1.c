#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>   
#include <sys/types.h> 
#include <sys/wait.h>  
#include <time.h>

void random_average_calculation(){
    int sum=0;
    const int start=1;
    const int end=100;

    unsigned int seed = (unsigned int)(time(0) + getpid());
    srand(seed);

    for(int i=1;i<5; i++){
        int num=start+rand()%(end-start+1);
        printf("Generated Random %d: %d\n",i, num);
        sum += num;
    }


    float average_value=sum/(float)4;
    printf("Average of generated numbers: %.2f\n", average_value);
}

int main(){

    for(int i=1; i<8; i++){
        pid_t child_pid=fork();  
        if(child_pid<0){
            printf("Error: Unable to create process.\n");
            exit(0);
        } 
        else if(child_pid==0){
            printf("\nChild Process %d (PID: %d)\n", i , getpid());
            random_average_calculation(); 
            exit(0);  
        } 
        else{
            wait(NULL);
        }
    }

    printf("\nAll child processes have completed.\n");

    return 0;
}