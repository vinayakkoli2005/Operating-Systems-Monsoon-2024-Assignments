#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>

#define MAX 16

void search(int arr[],int val,int lo,int hi){
    if(lo>hi){
        printf("%d: Nope!\n",getpid());
        exit(-1);
    }
    int mid=(lo+hi)/2;
    if(arr[mid]==val){
        printf("%d: Found at %d\n",getpid(),mid);
        exit(mid);
    }else if(arr[mid]>val){
        printf("%d: Left...\n",getpid());
        hi=mid-1;
    }else{
        printf("%d: Right...\n",getpid());
        lo=mid+1;
    }
    pid_t kid=fork();
    if(kid<0){
        fprintf(stderr,"%d: Fork fail\n",getpid());
        exit(EXIT_FAILURE);
    }else if(kid==0){
        printf("%d: Child goes\n",getpid());
        search(arr,val,lo,hi);
    }else{
        printf("%d: Waiting...\n",getpid());
        int status;
        wait(&status);
        if(WIFEXITED(status)&&WEXITSTATUS(status)==-1){
            printf("%d: Kid lost\n",getpid());
        }
    }
}

int main(){
    int nums[MAX]={3,6,9,12,15,18,21,24,27,30,33,34,35,35,100,101};
    int find_val;
    printf("Nums: ");
    int i=0;
    while(i<MAX){
        printf("%d ",nums[i]);
        i++;
    }
    printf("\nTarget? ");
    scanf("%d",&find_val);
    search(nums,find_val,0,MAX-1);
    return 0;
}