#include<stdio.h>
#include<stdbool.h>
#include<limits.h>

void swapValues(int* a,int* b){
    int temp=*a;
    *a=*b;
    *b=temp;
}

void sortArrival(int ids[],int arrive[],int time[],int size){
    int i=0;
    while(i<size-1){
        int j=0;
        while(j<size-i-1){
            if(arrive[j]>arrive[j+1]){
                swapValues(&arrive[j],&arrive[j+1]);
                swapValues(&time[j],&time[j+1]);
                swapValues(&ids[j],&ids[j+1]);
            }
            j++;
        }
        i++;
    }
}

void calculateFirst(int ids[],int arrive[],int time[],int size,int resp[],int turn[],int* totalResp,int* totalTurn){
    int current=0,i=0;
    while(i<size){
        if(current<arrive[i])current=arrive[i];
        printf("P%d @%d\n",ids[i],current);
        resp[i]=current-arrive[i];
        turn[i]=resp[i]+time[i];
        current+=time[i];
        *totalResp+=resp[i];
        *totalTurn+=turn[i];
        i++;
    }
}

void first(int ids[],int arrive[],int time[],int size){
    int resp[size],turn[size],totalResp=0,totalTurn=0;

    sortArrival(ids,arrive,time,size);
    calculateFirst(ids,arrive,time,size,resp,turn,&totalResp,&totalTurn);

    printf("\nAvgTurn:%.2f\n",(float)totalTurn/size);
    printf("AvgResp:%.2f\n",(float)totalResp/size);
}

void findShortestRemaining(int ids[],int arrive[],int remaining[],int size,int current){
    int i=0;
    while(i<size){
        if(arrive[i]<=current&&remaining[i]>0)return;
        i++;
    }
}

void processRemaining(int ids[],int arrive[],int time[],int remaining[],int resp[],bool firstResp[],int size,int* totalResp,int* totalTurn){
    int current=0,finished=0,last=-1,done[size],turn[size];

    while(finished<size){
        int shortIndex=-1,shortTime=INT_MAX,i=0;
        while(i<size){
            if(arrive[i]<=current&&remaining[i]>0&&remaining[i]<shortTime){
                shortTime=remaining[i];
                shortIndex=i;
            }
            i++;
        }

        if(shortIndex==-1){
            current++;
            continue;
        }

        if(shortIndex!=last){
            printf("%d: P%d\n",current,ids[shortIndex]);
            last=shortIndex;
        }

        if(firstResp[shortIndex]){
            resp[shortIndex]=current-arrive[shortIndex];
            firstResp[shortIndex]=false;
        }

        remaining[shortIndex]--;
        current++;

        if(remaining[shortIndex]==0){
            done[shortIndex]=current;
            turn[shortIndex]=done[shortIndex]-arrive[shortIndex];
            *totalTurn+=turn[shortIndex];
            *totalResp+=resp[shortIndex];
            finished++;
        }
    }
}

void shortRemaining(int ids[],int arrive[],int time[],int size){
    int remaining[size],resp[size],totalResp=0,totalTurn=0;
    bool firstResp[size];
    int i=0;

    while(i<size){
        remaining[i]=time[i];
        firstResp[i]=true;
        i++;
    }

    processRemaining(ids,arrive,time,remaining,resp,firstResp,size,&totalResp,&totalTurn);

    printf("\nAvgTurn:%.2f\n",(float)totalTurn/size);
    printf("AvgResp:%.2f\n",(float)totalResp/size);
}

void updateWaitTime(int ids[],int size,int time[],int wait[],int quantum,int arrive[],int done[]){
    int remaining[size],current=0,i=0;
    
    while(i<size){
        remaining[i]=time[i];
        i++;
    }

    while(1){
        bool allDone=true;
        i=0;
        while(i<size){
            if(remaining[i]>0){
                allDone=false;
                if(remaining[i]>quantum){
                    current+=quantum;
                    remaining[i]-=quantum;
                }else{
                    current+=remaining[i];
                    done[i]=current;
                    wait[i]=current-time[i]-arrive[i];
                    remaining[i]=0;
                }
            }
            i++;
        }
        if(allDone)break;
    }
}

void updateTurnAround(int ids[],int size,int time[],int wait[],int turn[],int arrive[],int done[]){
    int i=0;
    while(i<size){
        turn[i]=done[i]-arrive[i];
        i++;
    }
}

void roundRobin(int ids[],int arrive[],int time[],int size,int quantum){
    int wait[size],turn[size],done[size],totalWait=0,totalTurn=0;

    updateWaitTime(ids,size,time,wait,quantum,arrive,done);
    updateTurnAround(ids,size,time,wait,turn,arrive,done);

    int i=0;
    printf("\nID\tArrive\tTime\tDone\tTurn\tWait\n");
    while(i<size){
        printf("%d\t%d\t%d\t%d\t%d\t%d\n",ids[i],arrive[i],time[i],done[i],turn[i],wait[i]);
        totalWait+=wait[i];
        totalTurn+=turn[i];
        i++;
    }

    printf("\nAvgTurn:%.2f\n",(float)totalTurn/size);
    printf("AvgWait:%.2f\n",(float)totalWait/size);
}

int main(){
    int size;
    printf("Enter processes (size>4): ");
    scanf("%d",&size);

    int ids[size],arrive[size],time[size],i=0;
    while(i<size){
        printf("\nEnter ID, Arrive, Time: %d ",i);
        scanf("%d %d %d",&ids[i],&arrive[i],&time[i]);
        i++;
    }

    int quantum;
    printf("\nEnter quantum: ");
    scanf("%d",&quantum);

    first(ids,arrive,time,size);
    printf("SRTF\n");
    shortRemaining(ids,arrive,time,size);
    printf("RR\n");
    roundRobin(ids,arrive,time,size,quantum);
    return 0;
}