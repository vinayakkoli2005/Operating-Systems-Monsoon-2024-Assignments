#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>

void run(char *cmd,char *args[]){
    if(execvp(cmd,args)==-1){
        perror("execvp");
        exit(EXIT_FAILURE);
    }
}

int main(){
    pid_t pids[3];
    char *args1[]={"./date",NULL};
    char *args2[]={"./cal","9","2024",NULL};
    char *args3[]={"./uptime",NULL};

    int i=0;
    while(i<3){
        if((pids[i]=fork())==0){
            if(i==0)run("./date",args1);
            else if(i==1)run("./cal",args2);
            else run("./uptime",args3);
        }
        i++;
    }

    i=0;
    while(i<3){
        waitpid(pids[i],NULL,0);
        i++;
    }

    return 0;
}