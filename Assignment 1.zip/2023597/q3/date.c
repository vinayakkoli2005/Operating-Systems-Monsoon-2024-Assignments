#include<stdio.h>
#include<time.h>
#include<string.h>

int main(int argc,char*argv[]){
    time_t now=time(NULL);
    struct tm*lt=localtime(&now);
    char buf[80];

    if(argc>1&&strcmp(argv[1],"-u")==0){
        struct tm*utc=gmtime(&now);
        strftime(buf,80,"%Y-%m-%d %H:%M:%S UTC",utc);
    }else if(argc>1&&strcmp(argv[1],"-r")==0){
        strftime(buf,80,"%a, %d %b %Y %H:%M:%S %z",lt);
    }else{
        strftime(buf,80,"%Y-%m-%d %H:%M:%S",lt);
    }

    printf("%s\n",buf);
    return 0;
}