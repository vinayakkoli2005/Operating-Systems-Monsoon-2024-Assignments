#include<stdio.h>
#include<stdlib.h>

int zeller(int d,int m,int y){
    if(m<3){
        m+=12;
        y--;
    }
    int k=y%100;
    int j=y/100;
    int f=d+(13*(m+1))/5+k+k/4+j/4-2*j;
    return (f%7+7)%7;
}

int get_days_in_month(int m, int y) {
    if(m==2) {
        return ((y%4==0&&y%100!=0)||(y%400==0))?29:28;
    }
    return 31-((m-1)%7%2);
}

void print_cal(int m, int y){
    const char *days[]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
    printf("   %d %d\n",m,y);
    int i=0;
    while(i<7){
        printf("%s ",days[i]);
        i++;
    }
    printf("\n");

    int start=zeller(1,m,y);
    int days_in_m=get_days_in_month(m, y);

    i=0;
    while(i<start){
        printf("    ");
        i++;
    }

    int d=1;
    while(d<=days_in_m){
        printf("%3d ",d);
        if((start+d)%7==0)printf("\n");
        d++;
    }
    printf("\n");
}

int main(int argc, char *argv[]){
    if(argc!=3){
        printf("Usage: %s <month> <year>\n",argv[0]);
        return 1;
    }

    int m=atoi(argv[1]);
    int y=atoi(argv[2]);

    if(m<1||m>12||y<1){
        printf("Invalid month or year\n");
        return 1;
    }

    print_cal(m,y);
    return 0;
}