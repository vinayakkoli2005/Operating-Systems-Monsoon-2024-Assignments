#include<stdio.h>
#include<sys/sysinfo.h>

int main(){
    struct sysinfo info;

    if(sysinfo(&info)!=0){
        perror("sysinfo");
        return 1;
    }

    long up=info.uptime;
    int hrs=up/3600;
    int mins=(up%3600)/60;
    int secs=up%60;

    printf("Uptime: %d hours, %d minutes, %d seconds\n",hrs,mins,secs);
    return 0;
}