#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFFER_CAPACITY 10  // Maximum capacity of the warehouse buffer
#define MAX_DELIVERY 5      // Maximum products a truck can deliver
#define MAX_STORAGE 5       // Maximum products a manager can organize

// Circular buffer variables
int buffer[BUFFER_CAPACITY];
int deliver_index = 0;      // Index for next delivery (write position)
int organize_index = 0;     // Index for next organization (read position)
int total_products = 0;     // Current total products in the buffer

// Synchronization primitives
pthread_mutex_t mutex;
sem_t empty_slots;          // Semaphore to track empty slots
sem_t full_slots;           // Semaphore to track filled slots

// Delivery truck function: Adds products to the buffer
void* delivery_truck(void* arg) {
    int id = *((int*)arg);
    while (1) {
        int products = rand() % MAX_DELIVERY + 1; // Random products (1 to MAX_DELIVERY)

        // Check if buffer is full and print a message
        int empty_val;
        sem_getvalue(&empty_slots, &empty_val);
        if (empty_val <= 0) {
            printf("[Truck %d] Buffer full with all slots. Waiting...\n", id);
        }
        sem_wait(&empty_slots); // Wait for an empty slot

        pthread_mutex_lock(&mutex); // Lock the buffer

        // Add products to the buffer
        buffer[deliver_index] = products;
        deliver_index = (deliver_index + 1) % BUFFER_CAPACITY;
        total_products += products;

        printf("[Truck %d] Delivered %d products. Current Inventory: %d\n", id, products, total_products);

        pthread_mutex_unlock(&mutex); // Unlock the buffer
        sem_post(&full_slots); // Signal that the buffer has products

        sleep(rand() % 2 + 1); // Simulate delivery interval
    }
    return NULL;
}

// Storage manager function: Removes products from the buffer
void* storage_manager(void* arg) {
    int id = *((int*)arg);
    while (1) {
        // Check if buffer is empty and print a message
        int full_val;
        sem_getvalue(&full_slots, &full_val);
        if (full_val <= 0) {
            printf("[Manager %d] Buffer empty. Waiting for trucks to fill slots...\n", id);
        }
        sem_wait(&full_slots); // Wait for products in the buffer

        pthread_mutex_lock(&mutex); // Lock the buffer

        // Organize products from the buffer
        int products = buffer[organize_index];
        organize_index = (organize_index + 1) % BUFFER_CAPACITY;
        total_products -= products;

        printf("[Manager %d] Organized %d products. Current Inventory: %d\n", id, products, total_products);

        pthread_mutex_unlock(&mutex); // Unlock the buffer
        sem_post(&empty_slots); // Signal that the buffer has space

        sleep(rand() % 2 + 1); // Simulate organizing interval
    }
    return NULL;
}

int main() {
    int num_trucks, num_managers;

    // User inputs for the number of trucks and managers
    printf("Enter the number of delivery trucks: ");
    scanf("%d", &num_trucks);
    printf("Enter the number of storage managers: ");
    scanf("%d", &num_managers);

    pthread_t trucks[num_trucks], managers[num_managers];
    int truck_ids[num_trucks], manager_ids[num_managers];

    // Initialize semaphores and mutex
    sem_init(&empty_slots, 0, BUFFER_CAPACITY); // Initially, all slots are empty
    sem_init(&full_slots, 0, 0);                // Initially, no products in the buffer
    pthread_mutex_init(&mutex, NULL);

    // Create delivery truck threads
    for (int i = 0; i < num_trucks; i++) {
        truck_ids[i] = i + 1;
        pthread_create(&trucks[i], NULL, delivery_truck, &truck_ids[i]);
    }

    // Create storage manager threads
    for (int i = 0; i < num_managers; i++) {
        manager_ids[i] = i + 1;
        pthread_create(&managers[i], NULL, storage_manager, &manager_ids[i]);
    }

    // Let the program run for a fixed time, then exit
    sleep(20);

    // Clean up threads (not strictly necessary in this example)
    for (int i = 0; i < num_trucks; i++) {
        pthread_cancel(trucks[i]);
    }
    for (int i = 0; i < num_managers; i++) {
        pthread_cancel(managers[i]);
    }

    // Clean up resources
    sem_destroy(&empty_slots);
    sem_destroy(&full_slots);
    pthread_mutex_destroy(&mutex);

    printf("Simulation completed. Exiting.\n");
    return 0;
}

