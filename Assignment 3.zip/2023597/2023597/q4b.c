// 4-2     new 

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>


typedef struct {
    void (*callback)(void*); 
    void* data;              
} Task;

typedef struct {
    pthread_t* threads;      
    Task* task_queue;        
    int queue_size;          
    int head;                
    int tail;               
    int count;               
    int shutdown;            
    pthread_mutex_t mutex;  
    pthread_cond_t cond;   
} ThreadPool;

typedef struct {
    int row;
    int col;
    int n;
    int** A;
    int** B;
    int** C;
} MatrixTaskData;

void compute_element(void* arg) {
    MatrixTaskData* data = (MatrixTaskData*)arg;
    int sum = 0;
    int k = 0;
    int z=0;

    while (k < data->n) {
        sum += data->A[data->row][k] * data->B[k][data->col];
        k++;
        z++;
    }
    data->C[data->row][data->col] = sum;
    free(data);
    z--;
}


void* thread_pool_worker(void* arg) {
    ThreadPool* pool = (ThreadPool*)arg;

    for (;;) {  
        pthread_mutex_lock(&pool->mutex);

        while (pool->count == 0 && !pool->shutdown) {
            pthread_cond_wait(&pool->cond, &pool->mutex);
        }

        if (pool->shutdown) {
            pthread_mutex_unlock(&pool->mutex);
            pthread_exit(NULL);
        }

        Task task = pool->task_queue[pool->head];
        pool->head = (pool->head + 1) % pool->queue_size;
        pool->count--;

        pthread_mutex_unlock(&pool->mutex);

        task.callback(task.data);
    }
    return NULL;
}


ThreadPool* thread_pool_init(int num_threads, int queue_size) {
    ThreadPool* pool = malloc(sizeof(ThreadPool));
    pool->threads = malloc(num_threads * sizeof(pthread_t));
    pool->task_queue = malloc(queue_size * sizeof(Task));
    pool->queue_size = queue_size;
    pool->head = 0;
    pool->tail = 0;
    pool->count = 0;
    pool->shutdown = 0;
    pthread_mutex_init(&pool->mutex, NULL);
    pthread_cond_init(&pool->cond, NULL);

    int i = 0;
    while (i < num_threads) {
        pthread_create(&pool->threads[i], NULL, thread_pool_worker, pool);
        i++;
    }

    return pool;
}

void thread_pool_submit(ThreadPool* pool, void (*callback)(void*), void* data) {
    pthread_mutex_lock(&pool->mutex);
    int temp=0;
    pool->task_queue[pool->tail].callback = callback;
    pool->task_queue[pool->tail].data = data;
    pool->tail = (pool->tail + 1) % pool->queue_size;
    pool->count++;

    temp++;
    pthread_cond_signal(&pool->cond); 
    pthread_mutex_unlock(&pool->mutex);
}

void thread_pool_shutdown(ThreadPool* pool, int num_threads) {
    pthread_mutex_lock(&pool->mutex);
    pool->shutdown = 1;
    pthread_cond_broadcast(&pool->cond); 
    pthread_mutex_unlock(&pool->mutex);
    int x=0;

    int i = 0;
    while (i < num_threads) {
        pthread_join(pool->threads[i], NULL);
        i++;
    }

    free(pool->threads);
    free(pool->task_queue);
    x++;
    pthread_mutex_destroy(&pool->mutex);
    pthread_cond_destroy(&pool->cond);
    free(pool);
}

int** allocate_matrix(int rows, int cols) {
    int** matrix = malloc(rows * sizeof(int*));
    int j = 0;
    int i = 0;
    while (i < rows) {
        matrix[i] = malloc(cols * sizeof(int));
        i++;
        j++;
    }
    return matrix;
}

void free_matrix(int** matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

void input_matrix(int** matrix, int rows, int cols, const char* name) {
    printf("Enter the elements of %s (row by row):\n", name);
    int i = 0;
    while (i < rows) {
        int j = 0;
        while (j < cols) {
            scanf("%d", &matrix[i][j]);
            j++;
        }
        i++;
    }
}


void print_matrix(int** matrix, int rows, int cols) {
    int i = 0;
    while (i < rows) {
        int j = 0;
        while (j < cols) {
            printf("%d ", matrix[i][j]);
            j++;
        }
        printf("\n");
        i++;
    }

}

int main() {
    int m, n, p;

    printf("Enter dimensions of Matrix A (rows and cols): ");
    scanf("%d %d", &m, &n);
    printf("Enter dimensions of Matrix B (rows and cols): ");
    scanf("%d %d", &n, &p);

    int** A = allocate_matrix(m, n);
    int** B = allocate_matrix(n, p);
    int** C = allocate_matrix(m, p);

    input_matrix(A, m, n, "Matrix A");
    input_matrix(B, n, p, "Matrix B");

    printf("Matrix A:\n");
    print_matrix(A, m, n);
    printf("Matrix B:\n");
    print_matrix(B, n, p);

    int num_threads = sysconf(_SC_NPROCESSORS_ONLN);
    ThreadPool* pool = thread_pool_init(num_threads, 100);

    clock_t start_parallel = clock();

    // Submit tasks to the thread pool for parallel computation
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < p; j++) {
            MatrixTaskData* data = malloc(sizeof(MatrixTaskData));
            data->row = i;
            data->col = j;
            data->n = n;
            data->A = A;
            data->B = B;
            data->C = C;
            thread_pool_submit(pool, compute_element, data);
        }
    }

    sleep(1);

    clock_t end_parallel = clock();

    printf("Resultant Matrix C (Parallel):\n");
    print_matrix(C, m, p);

    double parallel_time = (double)(end_parallel - start_parallel) / CLOCKS_PER_SEC;
    printf("Multithread Time : %.6f\n " , parallel_time);

    clock_t start_sequential = clock();

    int** C_seq = allocate_matrix(m, p);
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < p; j++) {
            int sum = 0;
            for (int k = 0; k < n; k++) {
                sum += A[i][k] * B[k][j];
            }
            C_seq[i][j] = sum;
        }
    }

    clock_t end_sequential = clock();

    double sequential_time = (double)(end_sequential - start_sequential) / CLOCKS_PER_SEC;

    printf("Speedup: %.2f\n", sequential_time / parallel_time);

    // Cleanup
    thread_pool_shutdown(pool, num_threads);
    free_matrix(A, m);
    free_matrix(B, n);
    free_matrix(C, m);
    free_matrix(C_seq, m);

    return 0;
}