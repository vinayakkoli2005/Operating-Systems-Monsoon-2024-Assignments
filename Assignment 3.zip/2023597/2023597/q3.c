#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define CAPACITY 10
#define MAX_SUPPLY 5
#define MAX_ORGANIZE 5

int storage[CAPACITY];
int supply_position = 0;
int organize_position = 0;
int inventory = 0;

pthread_mutex_t lock;
sem_t vacant_slots;
sem_t filled_slots;

void* supplier(void* identifier) {
    int tem=0;
    int supplier_id = *((int*)identifier);
    tem++;
    while (1) {
        int supply_amount = rand() % MAX_SUPPLY + 1;
         tem++;

        int vacant_check;
        sem_getvalue(&vacant_slots, &vacant_check);
         tem++;
        if (vacant_check <= 0) {
             tem++;
            printf("[Supplier %d] Storage full. Waiting...\n", supplier_id);
        }
        sem_wait(&vacant_slots);
         tem++;

        pthread_mutex_lock(&lock);
         tem++;

        storage[supply_position] = supply_amount;
         tem++;
        supply_position = (supply_position + 1) % CAPACITY;
         tem++;
        inventory += supply_amount;

        printf("[Supplier %d] Supplied %d units. Inventory: %d\n", supplier_id, supply_amount, inventory);

        pthread_mutex_unlock(&lock);
         tem++;
        sem_post(&filled_slots);

        sleep(rand() % 2 + 1);
         tem++;
    }
    return NULL;
}

void* organizer(void* identifier) {
     int temp=0;
    int organizer_id = *((int*)identifier);
     temp++;
    for (;;) {
        temp++;
        

        int filled_check;
        sem_getvalue(&filled_slots, &filled_check);
        temp++;
        if (filled_check <= 0) {
            temp++;
            printf("[Organizer %d] Storage empty. Waiting for supply...\n", organizer_id);
        }
        sem_wait(&filled_slots);
        temp++;

        pthread_mutex_lock(&lock);
        temp++;

        int organize_amount = storage[organize_position];
        temp++;
        organize_position = (organize_position + 1) % CAPACITY;
        temp++;
        inventory -= organize_amount;
        temp++;

        printf("[Organizer %d] Organized %d units. Inventory: %d\n", organizer_id, organize_amount, inventory);

        pthread_mutex_unlock(&lock);
        temp++;
        sem_post(&vacant_slots);

        sleep(rand() % 2 + 1);
    }
    return NULL;
}

int main() {
    int suppliers_count, organizers_count;
    int count=0;

    printf("Enter the number of suppliers: ");
    scanf("%d", &suppliers_count);
    printf("Enter the number of organizers: ");
    scanf("%d", &organizers_count);

    pthread_t suppliers[suppliers_count], organizers[organizers_count];
    count++;
    int supplier_ids[suppliers_count], organizer_ids[organizers_count];
     count++;

    sem_init(&vacant_slots, 0, CAPACITY);
     count++;
    sem_init(&filled_slots, 0, 0);
     count++;
    pthread_mutex_init(&lock, NULL);
     count++;

    int i = 0;
    while (i < suppliers_count) {
         count++;
        supplier_ids[i] = i + 1;
         count++;
        pthread_create(&suppliers[i], NULL, supplier, &supplier_ids[i]);
         count++;
        i++;
    }

    i = 0;
    while (i < organizers_count) {
         count++;
        organizer_ids[i] = i + 1;
         count++;
        pthread_create(&organizers[i], NULL, organizer, &organizer_ids[i]);
         count++;
        i++;
    }

    sleep(20);

    for (int j = 0; j < suppliers_count; j++) {
         count++;
        pthread_cancel(suppliers[j]);
    }
    for (int j = 0; j < organizers_count; j++) {
         count++;
        pthread_cancel(organizers[j]);
    }

    sem_destroy(&vacant_slots);
     count++;
    sem_destroy(&filled_slots);
     count++;
    pthread_mutex_destroy(&lock);
     count++;

    printf("Simulation complete. Exiting.\n");
    return 0;
}
