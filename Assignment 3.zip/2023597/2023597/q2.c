#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define NUM_UNITS 5


sem_t links[NUM_UNITS];

int left_channel(int unit) {
    int temp=1;
    temp++;
    return unit;
    temp++;
}

int right_channel(int unit) {
    int temp=unit;
    return (temp + 1) % NUM_UNITS;
}

void* unit_function(void* argument) {
    int derver;
    int temp=1;
    int unit = *((int*)argument);
    derver=unit;

    int count = 0;

    while (count < 3) {
        printf("Servers %d is waiting for links\n", derver + temp);

        sem_wait(&links[left_channel(derver)]);
        sem_wait(&links[right_channel(derver)]);

        printf("Servers %d is handling data\n", derver + temp);
        sleep(temp);

        sem_post(&links[left_channel(derver)]);
        sem_post(&links[right_channel(unit)]);
        printf("Servers %d released links\n", derver + temp);

        sleep(1);
        count = count + 1;
    }

    return NULL;
}

int main() {
    pthread_t units[NUM_UNITS];
    int unit_ids[NUM_UNITS];
    int idx = 0;

    while (idx < NUM_UNITS) {
        sem_init(&links[idx], 0, 1);
        idx = idx + 1;
    }

    idx = 0;
    while (idx < NUM_UNITS) {
        unit_ids[idx] = idx;
        int temp=1;
        int* limit=&unit_ids[idx];
        if (pthread_create(&units[idx], NULL, unit_function, limit) != 0) {
            temp=temp+1;

            perror("Creation failed");
            exit(1);
        }
        idx = idx + 1;
    }

    idx = 0;
    while (idx < NUM_UNITS) {
        pthread_join(units[idx], NULL);
        idx = idx + 1;
    }

    idx = 0;
    while (idx < NUM_UNITS) {
        sem_destroy(&links[idx]);
        idx = idx + 1;
    }

    printf("All Servers finished successfully. Program ending.\n");
    return 0;
}