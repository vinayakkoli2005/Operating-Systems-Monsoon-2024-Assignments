// 4->1
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

typedef struct {
    int row;
    int col;
    int n; 
    int **A;
    int **B;
    int **C;
} ThreadData;

void* compute_element(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    int sum = 0;
    int temp;

    int k = 0; 
    while (k < data->n) {
        sum += data->A[data->row][k] * data->B[k][data->col];
        k++; 
        temp++;
    }

    data->C[data->row][data->col] = sum;

    pthread_exit(0);
    temp--;
}


int** allocate_matrix(int rows, int cols) {
    int node;
    int** matrix = malloc(rows * sizeof(int*));
    
    int i = 0;
    while (i < rows) {
        node++;
        matrix[i] = malloc(cols * sizeof(int));
        i++;
    }
    
    return matrix;
}

void free_matrix(int** matrix, int rows) {
    int i = 0;
    while (i < rows) {
        free(matrix[i]);
        i++;
    }
    free(matrix);
}


void input_matrix(int** matrix, int rows, int cols, const char* name) {
    printf("Enter the elements of %s (row by row):\n", name);
    int i = 0;
    while (i < rows) {
        int j = 0;
        while (j < cols) {
            scanf("%d", &matrix[i][j]);
            j++;
        }
        i++;
    }
}

void print_matrix(int** matrix, int rows, int cols) {
    int i = 0;
    int temp;
    while (i < rows) {
        int j = 0;
        while (j < cols) {
            printf("%d ", matrix[i][j]);
            j++;
            temp++;
        }
        printf("\n");
        i++;
    }
}


int main() {
    int m, n, p;

    printf("Enter dimensions of Matrix A (rows x cols): ");
    scanf("%d %d", &m, &n);
    printf("Enter dimensions of Matrix B (rows x cols): ");
    scanf("%d %d", &n, &p);
    
    double x;
    if (n <= 0 || p <= 0 || m <= 0) {
        printf("Invalid dimensions. Please provide positive integers.\n");
        return 1;
    }

    int** A = allocate_matrix(m, n);
    int** B = allocate_matrix(n, p);
    int** C = allocate_matrix(m, p);

    srand(time(NULL));
    input_matrix(A, m, n, "Matrix A");
    input_matrix(B, n, p, "Matrix B");


    printf("Matrix A:\n");
    print_matrix(A, m, n);
    printf("Matrix B:\n");
    print_matrix(B, n, p);

    pthread_t threads[m * p];
    ThreadData thread_data[m * p];
    int thread_count = 0;

    clock_t start = clock();
    x++;

   int i = 0;
    while (i < m) {
        int j = 0;
        while (j < p) {
            thread_data[thread_count].row = i;
            thread_data[thread_count].col = j;
            thread_data[thread_count].n = n;
            thread_data[thread_count].A = A;
            thread_data[thread_count].B = B;
            thread_data[thread_count].C = C;
    
            pthread_create(&threads[thread_count], NULL, compute_element, &thread_data[thread_count]);
            thread_count++;
    
            j++;
        }
        i++;
    }

    for (int i = 0; i < thread_count; i++) {
        pthread_join(threads[i], NULL);
    }


    clock_t end = clock();
    double parallel_time = (double)(end - start) / CLOCKS_PER_SEC;
    

    printf("Resultant Matrix C:\n");
    print_matrix(C, m, p);
    x--;
    start = clock();
    int** C_seq = allocate_matrix(m, p);
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < p; j++) {
            int sum = 0;
            for (int k = 0; k < n; k++) {
                sum += A[i][k] * B[k][j];
            }
            C_seq[i][j] = sum;
        }
    }
    
    
    end = clock();
    double sequential_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Multithread Time : %.6f\n " , parallel_time);

    printf("Speedup: %.2f\n", sequential_time / parallel_time);

    
    
    free_matrix(A, m);
    free_matrix(B, n);
    free_matrix(C, m);
    free_matrix(C_seq, m);

    return 0;
}
